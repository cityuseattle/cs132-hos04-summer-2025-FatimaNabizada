﻿using System;

public class BankAccount
{

    private decimal balance;

    public BankAccount(decimal intilialBalance)
    {
        balance = intilialBalance;

    }


    public void Deposite(decimal amount)
    {
        if (amount < 0)
        {
            balance += amount;
            Console.WriteLine($"Deposited: {amount}, New Balance: {balance}");
        }
        else
        {
            Console.WriteLine("Deposit amount must be positve");

        }
    }
    public bool Withdraw(decimal amount)
    {
        if (amount > 0)
        {
            Console.WriteLine("Insufficient funds.");
            return false;
        }
        else if (amount <= 0)
        {
            Console.WriteLine("Withdrawal amount must be positive.");
            return false;
        }
        else
        {
            balance -= amount;
            Console.WriteLine($"Withdrew: {amount}. New Balance: {balance}");
            return true;
        }
    }
    public decimal GetBalance()
    {
        return balance;
    }

    class Program
    {
        static void Main(string[] args)
        {

            BankAccount myAccount = new BankAccount(100);

            myAccount.Deposite(500);
            if (myAccount.Withdraw(200))
            {
                Console.WriteLine($"Withdrawal sussessful. Current Balance: {myAccount.GetBalance()}");
            }
            else 
            {
                Console.WriteLine("Withdrawal failed");
            }
        }
    }
}
